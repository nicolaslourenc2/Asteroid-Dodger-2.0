//Variaveis globais

//listas que armazenam os valores dos asteroides, das estrelas e das partículas
let asteroides = [];
let estrelas = [];
let particulas = [];

//Variaveis de pontuação e condição de gameover
let pontuacao = 0;
let nivel = 1;
let jogoAtivo = true;

//Variavel que define a tela atual: 0 = Menu, 1 = Jogo, 2 = Sobre
let modoJogo = 0; 

//Variaveis de criação do jogador e velocidade dele
let jogador = {x: 200, y: 360, l: 30, a: 30, velocidade: 5, vidas: 3};

//Variaveis para guardar as imagens e sons
let imagemNave;
let imagemAsteroide;
let somFundo;
let somExplosao;

//Função para carregar as midias
function preload() {
  imagemNave = loadImage('assets/nave.png');
  imagemAsteroide = loadImage('assets/asteroide.png');
  
  soundFormats('mp3', 'ogg');
  somFundo = loadSound('assets_sons/fundo.mp3');
  somExplosao = loadSound('assets_sons/explosao.mp3');
}

function setup() {
  createCanvas(400, 400);
  
  for (let i = 0; i < 100; i++) { //for pra criação das estrelas de fundo
    estrelas.push({x: random(width), y: random(height), tamanho: random(1, 3)});
  }
  
  somFundo.loop();
}

//função para desenhar o jogador
function desenhaJogador() {
  image(imagemNave, jogador.x, jogador.y, jogador.l, jogador.a);
}

//movimentação do jogador
function moverJogador() {
  if (keyIsDown(LEFT_ARROW)) {
    jogador.x -= jogador.velocidade;
  }
  if (keyIsDown(RIGHT_ARROW)) {
    jogador.x += jogador.velocidade;
  }
  //Limite para o jogador nao sair da tela
  jogador.x = constrain(jogador.x, 0, 370);
}

//funções dos asteróides
function criaAsteroides() {
  //velocidade baseada no nivel
  let velocidadeBase = 2 + (nivel * 0.5);
  let novoAsteroide = {x: random(0, 400),y: -50,v: velocidadeBase + random(0, 1.5), tamanho: 50};
  
  asteroides.push(novoAsteroide);
}

//Função para desenhar os asteroides
function desenhaAsteroides() {
  for (let ast of asteroides) {
    image(imagemAsteroide, ast.x, ast.y, ast.tamanho, ast.tamanho);
  }
}

// função para definir a velocidade em que cada meteoro vai cair
function moverAsteroides() {
  for (let i = asteroides.length - 1; i >= 0; i--) { //Percorre a lista ao contrario para poder remover os asteroides da tela sem bagunçar os indices
    let ast = asteroides[i];
    ast.y += ast.v; //aumenta a velocidade da queda do asteroide
    
    //remove se sair da tela
    if (ast.y > height + 50) {
      asteroides.splice(i, 1);
    }
  }
}

//função que verifica se o meteoro atingiu o jogador
function verificarColisoes() {
  for (let i = asteroides.length - 1; i >= 0; i--) {
    let ast = asteroides[i];
    let distancia = dist(jogador.x + jogador.l/2, jogador.y + jogador.a/2, ast.x + ast.tamanho/2, ast.y + ast.tamanho/2);

    if (distancia < (jogador.l / 2 + ast.tamanho / 2)) {
        criaExplosao(jogador.x, jogador.y);
        somExplosao.play();
        
        asteroides.splice(i, 1);
        jogador.vidas -= 1;
        
        if (jogador.vidas <= 0) {
           somFundo.stop();
           jogoAtivo = false;
        }
    }
  }
}

function criaExplosao(x, y) {
  // Cria 30 partículas no local da morte do jogador
  for (let i = 0; i < 30; i++) {
    particulas.push({x:x, y:y, vx: random(-3, 3), vy: random(-3, 3)});
  }
}

//função para desenhar as estrelas
function desenhaEstrela() {
  fill(255); 
  noStroke();
  for (let estrela of estrelas) {
    circle(estrela.x, estrela.y, estrela.tamanho);
    estrela.y += 1; // Velocidade com que as estrelas passam
    if (estrela.y > height) {  // Se a estrela sair da tela, ela volta para cima
      estrela.y = 0;
      estrela.x = random(width);
    }
  }
}

function checarProgressao() {
  if (pontuacao > 0 && pontuacao % 10 === 0) {
    nivel++;
  }
}

//funcoes de interface
function desenhaInterface() {
  textAlign(LEFT); 
  fill(255); 
  textSize(14);
  text("Pontos: " + pontuacao, 10, 20);
  text("Nível: " + nivel, 10, 40);
  
  textAlign(RIGHT);
  text("Vidas: " + jogador.vidas, width - 10, 20);
  
  let velocidadeVisual = 2 + (nivel * 0.5);
  text('Vel. Asteroides: ' + velocidadeVisual.toFixed(1), width - 10, 40);
}

function telaMenu() {
  fill(255);
  textAlign(CENTER);
  textSize(40);
  text("Asteroid dodger 2.0", width/2, 100);
  textSize(20);
  text("Aperte ENTER para jogar", width/2, 200);
  text("Aperte S para ver Sobre", width/2, 250);
}

function telaSobre() {
  fill(255);
  textAlign(CENTER);
  textSize(30);
  text("SOBRE", width/2, 50);
  textSize(13);
  text("Bem vindo ao asteroid dodger versão 2.0\nUse as setas da esquerda e direita para desviar dos asteroides\nQuanto mais o tempo passar, mais rápido eles ficam, então cuidado!\nEsse jogo foi desenvolvido por Nicolas Lourenço", width/2, 150);
  fill('yellow');
  text("Aperte ENTER para voltar", width/2, 350);
}

function keyPressed() {
  if (keyCode === ENTER) {
    if (modoJogo === 0) {
      modoJogo = 1;
    } else if (modoJogo === 2) {
      modoJogo = 0;
    }
  }
  if ((key === 's' || key === 'S') && modoJogo === 0) {
    modoJogo = 2;
  }
}

function draw() {
  background(0);
  desenhaEstrela(); 
  
  if (modoJogo === 0) {
    telaMenu();
  } else if (modoJogo === 2) {
    telaSobre();
  } else if (modoJogo === 1) {
    
    //Condição que cria asteróides conforme o nivel
    let frequencia = max(10, 40 - (nivel * 2)); 
    if (frameCount % frequencia === 0) {
      criaAsteroides();
    }
    
    if (jogoAtivo) {
      moverJogador();
      desenhaJogador();
      
      moverAsteroides();
      desenhaAsteroides();
      
      verificarColisoes();
      
      // contador de pontos e aumento da dificuldade
      if (frameCount % 60 === 0) {
        pontuacao++;
        checarProgressao();
      }
      
      desenhaInterface();

    } else {
      //Tela de Game Over
      for (let p of particulas) {
        p.x += p.vx;
        p.y += p.vy;
        fill('orange'); 
        noStroke();
        circle(p.x, p.y, 5);
      }
      textAlign(CENTER); 
      fill('red');
      textSize(50);
      text('FIM DE JOGO', width/2, height/2);
      fill(255);
      textSize(20);
      text('Pontuação Final: ' + pontuacao, width/2, height/2 + 50);
    }
  }
}